import {Admin,Url,projectName} from '../fixtures/Constants.json'
import { Login } from '../fixtures/LoginHelper'
import { CreateNewProject,DeleteNewProject } from '../fixtures/CreateProjectHelper'

describe('Create And Delete NewProject', () => {
    it('Create And Delete NewProject ', () => {
        cy.visit(Url)
        Login(Admin)
        CreateNewProject(projectName)
        DeleteNewProject(projectName)
    })
})