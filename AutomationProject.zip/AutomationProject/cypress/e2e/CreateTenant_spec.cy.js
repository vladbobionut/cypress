import {Admin,Url,tenantName,tenantWebsite,tenantEmail,tenantPhoneNumber,tenantPasword} from '../fixtures/Constants.json'
import { DeleteTenant,CreateTenant } from '../fixtures/CreateTenant'
import { Login } from '../fixtures/LoginHelper'

describe('Create and Delete Tenant', () => {
    it('Create and Delete Tenant ', () => {
        cy.visit(Url)
        Login(Admin)    
        CreateTenant(tenantName,tenantWebsite,tenantEmail,tenantPhoneNumber,tenantPasword)
        DeleteTenant(tenantName)
    })
})