import {Admin,Url,organisationName} from '../fixtures/Constants.json'
import { Login } from '../fixtures/LoginHelper'
import { CreateNewOrganisation,DeleteOrganisation } from '../fixtures/CreateOrganisation'


describe('Create and Delete Organisation', () => {
    it('Create and Delete Organisation ', () => {
        cy.visit(Url)
        Login(Admin)
      CreateNewOrganisation(organisationName)
      DeleteOrganisation(organisationName)
    })
})