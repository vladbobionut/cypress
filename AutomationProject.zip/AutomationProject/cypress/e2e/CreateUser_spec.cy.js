import {Admin,Url,userEmail,userPhone,userPasword} from '../fixtures/Constants.json'
import { CreateNewOrganisation, DeleteOrganisation } from '../fixtures/CreateOrganisation'
import { Login } from '../fixtures/LoginHelper'
import { CreateUser,DeleteUser } from '../fixtures/CreateUser'

describe('Create and Delete User', () => {
        context('720p resolution', () => {
          beforeEach(() => {
            cy.viewport(1231, 924)
          })       
     it('Create and Delete User ', () => {
     cy.visit(Url)
     Login(Admin)
     CreateNewOrganisation("GugustiucRevine")    
     CreateUser(userEmail,userPhone,userPasword)
     DeleteUser(userEmail)

     //delete organisation
     cy.get('[data-original-title="Organisations"] > .menu-link > .menu-icon').click()
     cy.get('.card-label',{timeout: 15000}).should('be.visible')
     DeleteOrganisation("GugustiucRevine")
    })
})
})