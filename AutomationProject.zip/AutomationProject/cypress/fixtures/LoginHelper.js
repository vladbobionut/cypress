import {password} from './Constants.json'

export const Login =(user) =>{
    cy.get('#Email').type(user)
    cy.get('#Password').type(password)
    cy.get('#kt_login_signin_submit').click()
    cy.get('#kt_quick_user_toggle',{timeout: 15000}).should('be.visible')
}