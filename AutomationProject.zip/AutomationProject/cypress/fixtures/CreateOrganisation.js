export const CreateNewOrganisation =(organisationName)=>{
    cy.get('[data-original-title="Organisations"] > .menu-link > .menu-icon').click()
    cy.get('.card-header',{timeout: 15000}).should('be.visible')
    cy.get('.card-toolbar > .btn').click()
    cy.get('.card-title',{timeout: 15000}).should('be.visible')
    cy.get('.k-select > .k-icon').click()
    cy.get('#TenantId_listbox > li:nth-child(1)').click()       
    cy.get('#Name').type(organisationName)
    cy.get('.btn-outline-primary').click()  
}

export const DeleteOrganisation =(organisationName)=>{
    cy.get('.card-label',{timeout: 15000}).should('be.visible')
    cy.contains('td', organisationName).parent().within($tr => { cy.get('td a') .contains('Delete').click() })
    cy.get('.btn-outline-primary',{timeout: 15000}).should('be.visible')
    cy.get('.btn-outline-primary').click()
    cy.get('#btnConfirmation',{timeout: 15000}).should('be.visible')
    cy.get('#btnConfirmation').click()
    cy.get('.card-label',{timeout: 15000}).should('be.visible')
}