import {tenantName,tenantWebsite,tenantEmail,tenantPhoneNumber,tenantPasword} from '../fixtures/Constants.json'

export const CreateTenant =(tenantName,website,email,phone,password)=>{
    cy.get('[data-original-title="Tenants"] > .menu-link').click()
    cy.get('.card-toolbar > .btn').click()
    cy.get('#Name',{timeout: 15000}).should('be.visible')
    cy.get('#Name').type(tenantName)
    cy.get('#WebSite').type(website)
    cy.get('.btn-outline-primary').click()
    cy.get('.card-label',{timeout: 15000}).should('be.visible')
    cy.get('#Email').type(email)
    cy.get(':nth-child(8) > .col-md-10 > .k-checkbox-label').click()
    cy.get('#PhoneNumber').type(phone)
    cy.get(':nth-child(10) > .col-md-10 > .k-checkbox-label').click()
    cy.get('#Password').type(password)
    cy.get('#ConfirmPassword').type(password)
    cy.get('.btn-outline-primary').click()  
}

export const DeleteTenant =(tenantName)=>{
    cy.get('.k-grid-content',{timeout: 15000}).should('be.visible')
    cy.contains('td', tenantName).parent().within($tr => { cy.get('td a') .contains('Delete').click() })
    cy.get('.card-body',{timeout: 15000}).should('be.visible')
    cy.get('.btn-outline-primary').scrollIntoView()
    cy.get('.btn-outline-primary').click()
    cy.get('#btnConfirmation',{timeout: 15000}).should('be.visible')
    cy.get('#btnConfirmation').click()
    cy.get('.card-label',{timeout: 15000}).should('be.visible')
    cy.get('.card-label').contains('User List')
    cy.get('[data-original-title="Tenants"] > .menu-link').click()
    cy.contains('td', tenantName).parent().within($tr => { cy.get('td a') .contains('Delete').click() })
    cy.get('.card-label',{timeout: 15000}).should('be.visible')
    cy.get('.btn-outline-primary').click()
    cy.get('#modalConfirmation > .modal-dialog > .modal-content > .modal-header',{timeout: 15000}).should('be.visible')
    cy.get('#btnConfirmation').click()
    cy.get('.card-label',{timeout: 15000}).should('be.visible')
}