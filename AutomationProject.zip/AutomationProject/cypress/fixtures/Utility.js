import {addIncorporationSuccessfullMessage,shareAmmount} from './Constants.json'
 export const  setDate = (d) => {
    const closedDate = new Date();

    const year = closedDate.getFullYear();
  
    const month = closedDate.getMonth() + 1;
  
    const day = closedDate.getDate()+d;
  
    return `${year}-${month < 10 ? `0${month}` : month}-${day < 10 ? `0${day}` : day}`;   
}
