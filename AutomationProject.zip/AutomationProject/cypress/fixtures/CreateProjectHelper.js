export const CreateNewProject =(projectName)=>{
    cy.get('[data-original-title="Projects"] > .menu-link > .menu-icon').click()
    cy.get('.card-toolbar > .btn',{timeout: 15000}).should('be.visible')
    cy.get('.card-toolbar > .btn').click()
    cy.get('#WorkspaceName',{timeout: 15000}).should('be.visible')
    cy.get('#WorkspaceName').type(projectName)
    cy.get('.btn-outline-primary').click()
    cy.get('.card-label',{timeout: 15000}).should('be.visible')
    cy.get('.btn-outline-primary').click()  
}

export const DeleteNewProject =(projectName)=>{
    cy.get('tbody > tr > :nth-child(1)',{timeout: 15000}).should('be.visible')
    cy.contains('td', projectName).parent().within($tr => { cy.get('td a') .contains('Delete').click() })
    cy.get('.card-body',{timeout: 15000}).should('be.visible')
    cy.get('.btn-outline-primary').scrollIntoView()
    cy.get('.btn-outline-primary').click()
    cy.get('#modalConfirmation > .modal-dialog > .modal-content > .modal-header',{timeout: 15000}).should('be.visible')
    cy.get('#btnConfirmation').click()
}